package com.hibernate.sample.dao;


import com.hibernate.sample.model.manyrelation.Account;
import com.hibernate.sample.model.manyrelation.Customer;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.HashSet;
import java.util.Set;

public class HibernateManyRelationshipTest {

    public static void main(String[] args) {
        //saveCustomer();
        //printCustomer();
        //printAccount();
        deleteCustomer();
    }

    private static void deleteCustomer(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();
        final Customer customer = session.get(Customer.class, 13L);
        customer.getAccount().clear();
        session.delete(customer);
        transaction.commit();
    }


    private static void printAccount(){
        final Session session = HibernateUtil.getSessionFactory().openSession();

        // By name
        final String name = "Savings";
        final Query query = session.createQuery("From Account where name = :name");
        query.setParameter("name", name);
        System.out.println("By Name -> " +query.list());

        // by Id
        final Account account = session.get(Account.class, 19L);
        System.out.println("By Id -> "+account);
    }



    private static void printCustomer(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Account account = session.get(Account.class, 5L);
        System.out.println(account);
    }

    private static void saveCustomer() {
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();

        final Customer customer = new Customer();
        customer.setName("Shyam");

        final Account account = new Account("HDFC0122323", "Savings");
        account.setCustomer(customer);
        final Account account1 = new Account("LXMII0122323", "Current");
        account1.setCustomer(customer);
        final Set<Account> accounts = new HashSet<>();
        accounts.add(account);
        accounts.add(account1);

        customer.setAccount(accounts);

        session.save(customer);
        transaction.commit();

        //Assignment - create a new account and add it to existing customer.
    }

}
