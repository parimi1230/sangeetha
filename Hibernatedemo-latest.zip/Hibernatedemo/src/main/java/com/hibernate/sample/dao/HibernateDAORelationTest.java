package com.hibernate.sample.dao;

import com.hibernate.sample.model.onetoone.Department;
import com.hibernate.sample.model.onetoone.Employee;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class HibernateDAORelationTest {

    public static void main(final String[] args) {
        //saveEmployeeWithOneToOneMapping();
        //getEmployeeWithOneToOneMapping();
        //deleteEmployeeWithOneToOneMapping();
        getEmployees();
    }

    private static void getEmployees(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Query query = session.createQuery("SELECT dept FROM Employee as emp INNER JOIN Department as dept ON dept.empId = emp.id where dept.empId = 1");
        final List<Department> list = (List<Department>)query.list();
        System.out.println(list);
    }

    private static void saveEmployeeWithOneToOneMapping() {
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();
        final Employee employee = session.get(Employee.class, 234L);
        final Department dept = new Department();
        dept.setName("IT");
        session.save(dept);

        final Department dept1 = new Department();
        dept.setName("IT 1");
        session.save(dept);
        transaction.commit();
    }

    private static void getEmployeeWithOneToOneMapping(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        System.out.println(session.get(Department.class, 1L));
    }


    private static void deleteEmployeeWithOneToOneMapping(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();
        final Department dept = new Department();
        dept.setId(4L);
        session.delete(dept);
        transaction.commit();
    }

}
