package com.hibernate.sample.dao;


import com.hibernate.sample.model.manytomany.Project;
import com.hibernate.sample.model.manytomany.Student;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.HashSet;
import java.util.Set;

public class HibernateManyToManyTest {

    public static void main(final String[] args) {
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();


        final Student student = new Student();
        student.setStudId(1L);
        student.setName("Jay");

        final Project project = new Project();
        project.setPjctId(001L);
        project.setName("Project1");

        final Project project1 = new Project();
        project1.setPjctId(002L);
        project1.setName("Project2");

        final Set<Project> projects = new HashSet<>();
        projects.add(project);
        projects.add(project1);
        student.setProjects(projects);

        session.save(student);
        transaction.commit();

    }

}
