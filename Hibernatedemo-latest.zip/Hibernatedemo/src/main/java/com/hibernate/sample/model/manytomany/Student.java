package com.hibernate.sample.model.manytomany;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Set;

@Entity
@Table(name="student")
public class Student implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="stud_id")
    private Long studId;

    @Column(name="s_name")
    private String name;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name="studs_projects", joinColumns = {@JoinColumn(name="s_id", referencedColumnName = "stud_id") },
            inverseJoinColumns = @JoinColumn(name="p_id", referencedColumnName = "pjct_id"))
    private Set<Project> projects;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStudId() {
        return studId;
    }

    public void setStudId(Long studId) {
        this.studId = studId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Project> getProjects() {
        return projects;
    }

    public void setProjects(Set<Project> projects) {
        this.projects = projects;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", studId=" + studId +
                ", name='" + name + '\'' +
                ", projects=" + projects +
                '}';
    }
}
