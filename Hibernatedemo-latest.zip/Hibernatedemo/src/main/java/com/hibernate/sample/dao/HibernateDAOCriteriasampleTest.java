package com.hibernate.sample.dao;


import com.hibernate.sample.model.onetoone.Employee;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

public class HibernateDAOCriteriasampleTest {

    public static void main(String[] args) {
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Criteria criteria = session.createCriteria(Employee.class);
        criteria.add(Restrictions.ge("id", 100L));
        final List<Employee> list = (List<Employee>) criteria.list();


/*
        final List<Employee> listResult = new ArrayList<>();
        for (final Employee employee : list) {
            if (employee.getName().equals("Sangeetha")) {
                listResult.add(employee);
            }
        }

        System.out.println(listResult);

        final List<Employee> java8FilterList = list.stream()
                .filter(xyz -> xyz.getName().equals("Sangeetha"))
                .map(xyz -> {
                    xyz.setName("testSangeetha");
                    return xyz;
                })
                .collect(Collectors.toList());
*/

/*        System.out.println(java8FilterList);*/

    }
}
