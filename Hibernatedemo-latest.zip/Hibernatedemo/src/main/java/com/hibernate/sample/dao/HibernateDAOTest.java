package com.hibernate.sample.dao;

import com.hibernate.sample.model.onetoone.Employee;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class HibernateDAOTest {

    public static void main(final String[] args) {
        //saveEmployee();
        System.out.println(getEmployee());
        //System.out.println(getEmployee());
        //System.out.println(loadEmployee());
        //updateEmployee();
        //deleteEmployee();
    }

    private static Employee getEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        return session.get(Employee.class, 125L);
    }

    private static List<Employee> getEmployees(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Query query = session.createQuery("From Employee E where E.name='sangeetha");
        return (List<Employee>)query.list();
    }

    private static Employee loadEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        return session.load(Employee.class, 125L);
    }

    private static void updateEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        final Employee employee = session.get(Employee.class, 234L);
        employee.setName("Sangeetha S");
        session.update(employee);
        tx.commit();
    }

    private static void deleteEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction tx = session.beginTransaction();
        final Employee employee = session.get(Employee.class, 234L);
        session.delete(employee);
        tx.commit();
    }

    private static void saveEmployee() {
        final Employee employee = new Employee();
        employee.setId(237L);
        employee.setName("Sangeetha");
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction tx = session.beginTransaction();
        try {
            session.save(employee);
            tx.commit();
        } finally {
            session.close();
        }
    }

}
