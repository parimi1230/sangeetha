package com.example.demo.service;


import com.example.demo.model.dev.Employee;
import com.example.demo.repositories.dev.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService{


    private final EmployeeRepository repository;

    @Autowired
    public EmployeeServiceImpl(final EmployeeRepository repository){
        this.repository = repository;
    }


    public List<Employee> getEmployees() {
        return repository.findAll();
    }

    @Override
    public Employee getEmployeeById(final Long id) {
        final List<Employee> emps = repository.findByName("James");
        final List<Employee> emps1 = repository.findByCity("Chennai");
        final List<Employee> empsByCityParam = repository.getCitiesByParam("Chennai");
        final List<Employee> empsByPositionalParams = repository.getCities("Chennai", "James");

        return repository.findById(id).orElseThrow(() -> new RuntimeException("No data available"));
    }

    @Override
    public void saveEmployee(final Employee employee){
        repository.save(employee);
    }

    @Override
    public void updateEmployee(final Employee employee) {
        final Employee emp = repository.getOne(employee.getId());
        emp.setName(employee.getName());
        repository.save(emp);
    }

    @Override
    public void deleteEmployeeById(final Long id) {
        repository.deleteById(id);
    }


    @Override
    @Transactional
    public void saveAndDelete(){
        final Employee employee = new Employee();
        employee.setName("Yesh");
        employee.setCity("Andhra1");
        saveEmployee(employee);

        final Employee emp = repository.getOne(1L);
        emp.setCity("Madras12");
        repository.save(emp);
    }

    public void throwSomeRuntimeException(){
        throw new RuntimeException();
    }
}
