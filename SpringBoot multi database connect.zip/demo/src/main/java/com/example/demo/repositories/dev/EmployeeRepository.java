package com.example.demo.repositories.dev;


import com.example.demo.model.dev.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    //By Method Signature.
    List<Employee> findByName(final String name);

    List<Employee> findByCity(final String city);

    //by Using @Query named Parameter
    @Query("SELECT E from Employee E where E.city=:city1")
    List<Employee> getCitiesByParam(@Param("city1") final String city);

    //by Using @Query positional Parameter
    @Query("SELECT E from Employee E where E.city=?1 and E.name=?2")
    List<Employee> getCities(final String city, final String name);

}
