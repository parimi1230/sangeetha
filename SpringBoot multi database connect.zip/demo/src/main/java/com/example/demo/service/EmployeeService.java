package com.example.demo.service;


import com.example.demo.model.dev.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> getEmployees();
    Employee getEmployeeById(Long id);
    void saveEmployee(final Employee employee);
    void updateEmployee(Employee employee);
    void deleteEmployeeById(final Long id);
    void saveAndDelete();
}
