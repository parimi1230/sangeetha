package com.example.demo.controller;

import com.example.demo.model.dev.Employee;
import com.example.demo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employees")
    public List<Employee> getEmployees() {
        return employeeService.getEmployees();
    }

    @GetMapping("/employee/{id}")
    public Employee getEmployee(@PathVariable final Long id) {
        //employeeService.saveAndDelete();
        return employeeService.getEmployeeById(id);
    }

    @PostMapping("/employee/add")
    public void addStudent(@RequestBody final Employee employee) {
        employeeService.saveEmployee(employee);
    }

    @PutMapping("/employee/update")
    public void updateStudent(@RequestBody final Employee employee) {
        employeeService.updateEmployee(employee);
    }

    @DeleteMapping("/employee/delete/{id}")
    public void deleteStudent(@PathVariable final Long id) {
        employeeService.deleteEmployeeById(id);
    }

}
