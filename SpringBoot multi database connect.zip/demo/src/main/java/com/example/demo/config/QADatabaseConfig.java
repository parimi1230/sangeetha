package com.example.demo.config;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
@EnableJpaRepositories(
        entityManagerFactoryRef = "qaEntityManagerFactory",
        transactionManagerRef = "qaTransactionManager",
        basePackages = "com.example.demo.repositories.qa" )
public class QADatabaseConfig {

    @Bean
    @ConfigurationProperties(prefix = "app.qa.datasource")
    public DataSource getQADataSource(){
        return DataSourceBuilder.create().build();
    }

    //Take a look at spring MVC sample for how we configured session factory
    @Bean(name="qaEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean getQAEntitymanagerBean(final EntityManagerFactoryBuilder builder){
        return builder.dataSource(getQADataSource())
                .packages("com.example.demo.model.qa")
                .persistenceUnit("myQADataSource")
                .build();
    }

    @Bean(name="qaTransactionManager")
    public PlatformTransactionManager getQATransactionManager(@Qualifier("qaEntityManagerFactory") final EntityManagerFactory entityManagerFactory){
        return new JpaTransactionManager(entityManagerFactory);
    }

}
