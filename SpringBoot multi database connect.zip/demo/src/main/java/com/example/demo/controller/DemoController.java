package com.example.demo.controller;

import com.example.demo.model.Student;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
public class DemoController {

    // For injecting property from application.properties file.
    @Value("${my.demo.sample.name}")
    private String name;

    static final Map<Integer, Student> students = new HashMap<>();

    @GetMapping("/student/{id}")
    public Student getStudent(@PathVariable final Integer id) {
        return students.get(id);
    }

    @GetMapping("/students")
    public Map<Integer, Student> getStudents() {
        return students;
    }

    @PostMapping("/add/student")
    public void addStudent(@RequestBody final Student student) {
        students.put(students.size() + 1, student);
    }

    @PutMapping("/student/update/{id}")
    public void updateStudent(@PathVariable final Integer id, @RequestBody final Student student) {
        students.put(id, student);
    }

    @DeleteMapping("/student/delete/{id}")
    public void deleteStudent(@PathVariable final Integer id) {
        students.remove(id);
    }
}
