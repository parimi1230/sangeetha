package com.hibernate.sample.dao;


import com.hibernate.sample.model.Department;
import com.hibernate.sample.model.Employee;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HibernateDAORelationTest {

    public static void main(final String[] args) {
        //saveEmployeeWithOneToOneMapping();
        //getEmployeeWithOneToOneMapping();
        deleteEmployeeWithOneToOneMapping();
    }

    private static void saveEmployeeWithOneToOneMapping() {
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();
        final Employee employee = session.get(Employee.class, 234L);
        final Department dept = new Department();
        dept.setName("IT");
        dept.setDescription("IT Batch");
        dept.setEmployee(employee);
        session.save(dept);
        final Department dept1 = new Department();
        dept.setName("IT 1");
        dept.setDescription("IT Batch 1");
        dept.setEmployee(employee);
        session.save(dept);
        transaction.commit();
    }

    private static void getEmployeeWithOneToOneMapping(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        System.out.println(session.get(Department.class, 4L));
    }


    private static void deleteEmployeeWithOneToOneMapping(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction transaction = session.beginTransaction();
        final Department dept = new Department();
        dept.setId(4L);
        session.delete(dept);
        transaction.commit();
    }

}
