package com.hibernate.sample.dao;

import com.hibernate.sample.model.Employee;
import com.hibernate.sample.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HibernateDAOTest {

    public static void main(final String[] args) {
        //saveEmployee();
        //System.out.println(getEmployee());
        //updateEmployee();
        deleteEmployee();
    }

    private static Employee getEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        return session.get(Employee.class, 234L);
    }

    private static void updateEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        final Employee employee = session.get(Employee.class, 234L);
        employee.setName("Sangeetha S");
        session.update(employee);
        tx.commit();
    }

    private static void deleteEmployee(){
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction tx = session.beginTransaction();
        final Employee employee = session.get(Employee.class, 234L);
        session.delete(employee);
        tx.commit();
    }

    private static void saveEmployee() {
        final Session session = HibernateUtil.getSessionFactory().openSession();
        final Transaction tx = session.beginTransaction();
        try {
            final Employee employee = new Employee();
            employee.setId(234L);
            employee.setName("Sangeetha");
            session.save(employee);
            tx.commit();
        } finally {
            session.close();
        }
    }

}
