package com.sample.springmvcdemo.controller;

import com.sample.springmvcdemo.controller.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Arrays;
import java.util.List;


@Controller
public class DemoController {

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String getEmployee() {
        return "hello_world";
    }

    @ResponseBody
    @RequestMapping(value = "/sum", method = RequestMethod.GET)
    public Integer getSum(final Integer a, final Integer b) {
        if(a==10){
            throw new RuntimeException();
        }
        return a + b;
    }

    @ResponseBody
    @RequestMapping(value = "/employee", method = RequestMethod.GET)
    public List<Employee> getEmployee(final Integer a, final Integer b) {
        final Employee employee = new Employee("Shankar", "25");
        final Employee employee1 = new Employee("Ravi", "35");
        return Arrays.asList(employee, employee1);
    }
}
